mpiexec -n 20 hrr_p.exe
