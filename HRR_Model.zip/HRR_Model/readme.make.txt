del *.mod
del *.obj
mpiifort variables15.f90 mpicalls15.f90 inputdata15.f90 outputdata15.f90 excesscalc15.f90 qsubsurface_kw15.f90 qsurface_kw15.f90 qchannel_mc15.f90 hillsloperouting15.f90 riverrouting15.f90 main15day.f90 -o hrr_p 
